# The furthest gene index that an individual made it to before dying
furthest = 1
# Default time
time = 400
# Default distance (x_pos)
dist = 0
# Stores individuals in order by index
ids = {}
# Stores best time of individuals by index
times = []
# Determines pop size (default 10)
pop_size = 10
# Determines size of individuals (default 1000)
size = 1000
